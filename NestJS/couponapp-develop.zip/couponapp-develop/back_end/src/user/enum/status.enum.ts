export enum  UserStatus {
    Active = 'Active',
    InActive = 'InActive',
}