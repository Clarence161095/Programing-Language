export interface TokenPayload {
    userId: string,
}